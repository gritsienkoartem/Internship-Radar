# Internship Radar — Telegram Bot API

Готовая версия без `api_id` / `api_hash` и без Telethon.

## Что умеет

- принимает новые посты из Telegram-каналов через Bot API;
- фильтрует по ключевым словам;
- rule-based scoring 0–100;
- Python/backend/Intern/Junior профиль;
- учитывает FastAPI, Django, PostgreSQL, Redis, Docker, Git, Linux и т.д.;
- штрафует frontend, продажи, маркетинг, 1C, manual QA и большой опыт;
- SQLite: вакансии, история, feedback и настройки;
- дедупликация по source+message_id и hash текста;
- кнопки `Открыть`, `Подходит`, `Не подходит`, `Скрыть похожие`;
- команды `/profile`, `/filter`, `/channels`, `/vacancies`, `/favorites`, `/history`, `/stats`, `/settings`.

## Важное ограничение Bot API

Эта версия получает **новые** посты, которые Telegram доставляет боту. Для каждого источника добавь бота в канал; на практике лучше дать ему права администратора. Bot API использует `channel_post` updates. Старую историю канала бот задним числом не сканирует.

## Установка Windows

```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

Открой `.env` и заполни:

```env
BOT_TOKEN=токен_от_BotFather
TELEGRAM_CHANNELS=@channel1,@channel2
TELEGRAM_KEYWORDS=python,backend,стажировка,intern,junior,fastapi,django
MIN_SCORE=60
MIN_SALARY_RUB=0
```

Запуск:

```powershell
python run.py
```

После запуска открой своего бота в Telegram и отправь `/start`. Бот сохранит твой chat_id и будет присылать подходящие вакансии.

## Как добавить каналы

1. Открой нужный канал.
2. Добавь своего бота в канал.
3. Дай боту необходимые права для получения постов.
4. Добавь username канала в `TELEGRAM_CHANNELS`.
5. Перезапусти `python run.py`.

## Фильтры

```text
/setscore 70
/setminsalary 60000
```

`/filter` покажет текущие значения.

## Безопасность

Не публикуй `.env` и никому не отправляй `BOT_TOKEN`. В проекте нет `api_id`/`api_hash`, пользовательская MTProto-сессия не используется.

## Принцип scoring

Плюсы: Python +25, Backend +20, Intern +15, Junior +12, без опыта +10, FastAPI +7, PostgreSQL +5, Redis +5, Docker +5, Москва/Remote +5 и др.

Минусы: frontend -30, дизайн -30, marketing -40, sales -50, 1C -40, manual QA -30, 3+ years -25 и др.

Итог ограничивается диапазоном 0–100.
