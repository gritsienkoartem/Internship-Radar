import asyncio
import hashlib
import html
import os
import re
import sqlite3
from datetime import datetime, timezone
from urllib.parse import urlparse

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
OWNER_USER_ID = os.getenv("OWNER_USER_ID", "").strip()
CHANNELS = [x.strip().lower() for x in os.getenv("TELEGRAM_CHANNELS", "").split(",") if x.strip()]
KEYWORDS = [x.strip().lower() for x in os.getenv("TELEGRAM_KEYWORDS", "").split(",") if x.strip()]
MIN_SCORE = int(os.getenv("MIN_SCORE", "60"))
MIN_SALARY = int(os.getenv("MIN_SALARY_RUB", "0"))
DB_PATH = os.getenv("DB_PATH", "vacancies.sqlite3")

POSITIVE = {
    "python": 25, "backend": 20, "стажировка": 15, "intern": 15,
    "internship": 15, "без опыта": 10, "no experience": 10,
    "fastapi": 7, "django": 7, "flask": 5, "postgresql": 5, "postgres": 5,
    "sql": 4, "redis": 5, "docker": 5, "git": 3, "rest api": 4,
    "linux": 3, "москва": 5, "remote": 5, "удаленно": 5, "удалённо": 5,
    "гибрид": 3, "junior": 12,
}
NEGATIVE = {
    "frontend": -30, "front-end": -30, "html": -15, "css": -15,
    "дизайн": -30, "marketing": -40, "маркетинг": -40,
    "sales": -50, "продажи": -50, "smm": -40, "hr": -35,
    "1c": -40, "ручное тестирование": -30, "manual qa": -30,
    "non-programming": -30, "3+ years": -25, "3 года": -25,
    "4 года": -25, "5 лет": -25,
}
TECHS = ["Python","FastAPI","Django","Flask","PostgreSQL","Postgres","SQL","Redis",
         "Docker","Git","REST API","Linux","Celery","RabbitMQ","Kafka","Pytest",
         "asyncio","SQLAlchemy","Pydantic","Kubernetes","AWS","C++","Java","Go"]

router = Router()

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    c=db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      user_id INTEGER PRIMARY KEY, username TEXT, chat_id INTEGER, created_at TEXT, last_seen TEXT
    );
    CREATE TABLE IF NOT EXISTS vacancies(
      id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT, channel TEXT, message_id INTEGER,
      title TEXT, company TEXT, url TEXT, text TEXT, score INTEGER, salary INTEGER,
      techs TEXT, location TEXT, work_format TEXT, experience TEXT, created_at TEXT,
      text_hash TEXT UNIQUE
    );
    CREATE UNIQUE INDEX IF NOT EXISTS idx_source_msg ON vacancies(source,message_id);
    CREATE TABLE IF NOT EXISTS feedback(
      id INTEGER PRIMARY KEY AUTOINCREMENT, vacancy_id INTEGER, user_id INTEGER,
      action TEXT, created_at TEXT, UNIQUE(vacancy_id,user_id)
    );
    CREATE TABLE IF NOT EXISTS settings(
      user_id INTEGER PRIMARY KEY, min_score INTEGER, min_salary INTEGER
    );
    """)
    c.commit(); c.close()

def owner_ok(user_id:int)->bool:
    return not OWNER_USER_ID or str(user_id)==OWNER_USER_ID

def save_user(m:Message):
    c=db(); now=datetime.now(timezone.utc).isoformat()
    c.execute("""INSERT INTO users(user_id,username,chat_id,created_at,last_seen)
                 VALUES(?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET
                 username=excluded.username,chat_id=excluded.chat_id,last_seen=excluded.last_seen""",
              (m.from_user.id,m.from_user.username,m.chat.id,now,now))
    c.execute("""INSERT INTO settings(user_id,min_score,min_salary) VALUES(?,?,?)
                 ON CONFLICT(user_id) DO NOTHING""",(m.from_user.id,MIN_SCORE,MIN_SALARY))
    c.commit(); c.close()

def user_settings(uid):
    c=db(); r=c.execute("SELECT * FROM settings WHERE user_id=?",(uid,)).fetchone(); c.close()
    return (r["min_score"],r["min_salary"]) if r else (MIN_SCORE,MIN_SALARY)

def normalize(s): return re.sub(r"\s+"," ",(s or "").strip().lower())

def parse_salary(text):
    vals=[]
    for m in re.finditer(r"(?<!\d)(\d{2,3}(?:[ .]\d{3})?|\d{4,6})\s*(?:₽|руб(?:\.|лей)?|р\b)",text.lower()):
        try: vals.append(int(re.sub(r"[ .]","",m.group(1))))
        except ValueError: pass
    return max(vals) if vals else 0

def find_url(text):
    m=re.search(r"https?://[^\s<>()]+",text)
    return m.group(0).rstrip(".,)") if m else ""

def title_from(text):
    lines=[x.strip() for x in text.splitlines() if x.strip()]
    return (lines[0][:180] if lines else "Вакансия")

def extract_field(text, labels):
    for label in labels:
        m=re.search(rf"{re.escape(label)}\s*[:—-]\s*(.+)",text,re.I)
        if m: return m.group(1).strip()[:120]
    return ""

def extract_techs(text):
    low=text.lower()
    return [t for t in TECHS if t.lower() in low]

def score(text):
    low=normalize(text)
    total=0; hits=[]; misses=[]
    for k,v in POSITIVE.items():
        if k in low: total+=v; hits.append(k)
    for k,v in NEGATIVE.items():
        if k in low: total+=v; misses.append(k)
    return max(0,min(100,total)),hits,misses

def keyword_ok(text):
    if not KEYWORDS: return True
    low=text.lower()
    return any(k in low for k in KEYWORDS)

def build_vacancy(message:Message):
    text=message.text or message.caption or ""
    if not text or not keyword_ok(text): return None
    sc,hits,misses=score(text)
    salary=parse_salary(text)
    location=extract_field(text,["Локация","Город","Location","City"])
    work=extract_field(text,["Формат","Work format","Формат работы"])
    exp=extract_field(text,["Опыт","Experience","Требуемый опыт"])
    company=extract_field(text,["Компания","Company","Работодатель"])
    url=find_url(text)
    if not url and message.chat.username and message.message_id:
        url=f"https://t.me/{message.chat.username}/{message.message_id}"
    channel=("@"+message.chat.username).lower() if message.chat.username else str(message.chat.id)
    title=title_from(text)
    h=hashlib.sha256(normalize(title+"|"+company+"|"+text).encode()).hexdigest()
    return dict(source="bot_api",channel=channel,message_id=message.message_id,title=title,
                company=company,url=url,text=text,score=sc,salary=salary,
                techs=", ".join(extract_techs(text)),location=location,
                work_format=work,experience=exp,created_at=datetime.now(timezone.utc).isoformat(),
                text_hash=h,hits=hits,misses=misses)

def store(v):
    c=db()
    try:
        cur=c.execute("""INSERT INTO vacancies(source,channel,message_id,title,company,url,text,score,salary,techs,
          location,work_format,experience,created_at,text_hash) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
          tuple(v[k] for k in ["source","channel","message_id","title","company","url","text","score","salary","techs","location","work_format","experience","created_at","text_hash"]))
        c.commit(); vid=cur.lastrowid
    except sqlite3.IntegrityError: vid=None
    c.close(); return vid

def vacancy_keyboard(v):
    rows=[]
    if v["url"]: rows.append([InlineKeyboardButton(text="🔗 Открыть вакансию",url=v["url"])])
    rows.append([
        InlineKeyboardButton(text="👍 Подходит",callback_data=f"good:{v['id']}"),
        InlineKeyboardButton(text="👎 Не подходит",callback_data=f"bad:{v['id']}"),
    ])
    rows.append([InlineKeyboardButton(text="🚫 Скрыть похожие",callback_data=f"hide:{v['id']}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)

def format_vacancy(v):
    tech=html.escape(v["techs"] or "—")
    why=" + ".join(v.get("hits",[])[:8]) if v.get("hits") else "совпадение по профилю"
    sal=f'{v["salary"]:,} ₽' if v["salary"] else "не указана"
    return (f"<b>🎯 {v['score']}/100 — {html.escape(v['title'])}</b>\n"
            f"🏢 {html.escape(v['company'] or 'не указана')}\n"
            f"🧰 {tech}\n"
            f"📍 {html.escape(v['location'] or 'не указана')}\n"
            f"💼 {html.escape(v['work_format'] or 'не указан')}\n"
            f"📚 Опыт: {html.escape(v['experience'] or 'не указан')}\n"
            f"💰 Зарплата: {sal}\n"
            f"💡 Почему подходит: {html.escape(why)}\n"
            f"📡 Источник: {html.escape(v['channel'])}")

async def notify(bot:Bot,v,uid):
    if v["score"]<uid[0] or (uid[1] and v["salary"] and v["salary"]<uid[1]): return
    await bot.send_message(uid[2],format_vacancy(v),reply_markup=vacancy_keyboard(v))

@router.message(Command("start"))
async def start(m:Message):
    if not owner_ok(m.from_user.id): return await m.answer("Доступ закрыт.")
    save_user(m)
    await m.answer("🚀 <b>Internship Radar</b> запущен.\n\nЯ слежу за новыми постами в заданных Telegram-каналах, оцениваю вакансии по правилу 0–100 и присылаю подходящие.\n\n/start — регистрация\n/profile — профиль\n/filter — фильтры\n/channels — каналы\n/vacancies — последние\n/favorites — подходящие\n/history — история\n/stats — статистика\n/settings — настройки\n/help — помощь")

@router.message(Command("help"))
async def help_(m:Message):
    if not owner_ok(m.from_user.id): return
    await m.answer("<b>Команды</b>\n/profile — профиль поиска\n/filter — текущие фильтры\n/settings — настройки\n/channels — источники\n/vacancies — последние вакансии\n/favorites — отмеченные 👍\n/history — история\n/stats — статистика\n\nИзменение фильтров: /setscore 70 или /setminsalary 60000")

@router.message(Command("profile"))
async def profile(m:Message):
    if not owner_ok(m.from_user.id): return
    await m.answer("<b>Профиль</b>\nBackend Development\nPython\nIntern / Junior\nМосква / Remote / Hybrid\n\nПриоритеты: Python, FastAPI, Django, Flask, PostgreSQL, SQL, Redis, Docker, Git, REST API, Linux.")

@router.message(Command("filter"))
async def filt(m:Message):
    if not owner_ok(m.from_user.id): return
    s,ms=user_settings(m.from_user.id)
    await m.answer(f"<b>Фильтры</b>\nМинимальный score: <b>{s}</b>\nМинимальная зарплата: <b>{ms:,} ₽</b>\nКлючевые слова: {html.escape(', '.join(KEYWORDS) or 'все')}")

@router.message(Command("settings"))
async def settings(m:Message):
    if not owner_ok(m.from_user.id): return
    await filt(m)

@router.message(Command("setscore"))
async def setscore(m:Message):
    if not owner_ok(m.from_user.id): return
    parts=m.text.split()
    if len(parts)!=2 or not parts[1].isdigit(): return await m.answer("Пример: /setscore 70")
    n=max(0,min(100,int(parts[1]))); c=db()
    c.execute("UPDATE settings SET min_score=? WHERE user_id=?",(n,m.from_user.id)); c.commit(); c.close()
    await m.answer(f"Готово: минимальный score = <b>{n}</b>")

@router.message(Command("setminsalary"))
async def setminsalary(m:Message):
    if not owner_ok(m.from_user.id): return
    parts=m.text.split()
    if len(parts)!=2 or not parts[1].isdigit(): return await m.answer("Пример: /setminsalary 60000")
    n=max(0,int(parts[1])); c=db()
    c.execute("UPDATE settings SET min_salary=? WHERE user_id=?",(n,m.from_user.id)); c.commit(); c.close()
    await m.answer(f"Готово: минимальная зарплата = <b>{n:,} ₽</b>")

@router.message(Command("channels"))
async def channels(m:Message):
    if not owner_ok(m.from_user.id): return
    await m.answer("<b>Каналы</b>\n"+("\n".join("• "+html.escape(x) for x in CHANNELS) if CHANNELS else "Список пуст."))

async def list_vac(m, mode="all"):
    if not owner_ok(m.from_user.id): return
    c=db()
    if mode=="good":
        rows=c.execute("""SELECT v.* FROM vacancies v JOIN feedback f ON f.vacancy_id=v.id
                          WHERE f.user_id=? AND f.action='good' ORDER BY v.id DESC LIMIT 10""",(m.from_user.id,)).fetchall()
    else:
        rows=c.execute("SELECT * FROM vacancies ORDER BY id DESC LIMIT 10").fetchall()
    c.close()
    if not rows: return await m.answer("Пока пусто.")
    await m.answer("\n\n".join(f"#{r['id']} <b>{html.escape(r['title'])}</b> — {r['score']}/100\n{html.escape(r['url'] or r['channel'])}" for r in rows))

@router.message(Command("vacancies"))
async def vacancies(m:Message): await list_vac(m)
@router.message(Command("history"))
async def history(m:Message): await list_vac(m)
@router.message(Command("favorites"))
async def favorites(m:Message): await list_vac(m,"good")

@router.message(Command("stats"))
async def stats(m:Message):
    if not owner_ok(m.from_user.id): return
    c=db()
    total=c.execute("SELECT COUNT(*) n FROM vacancies").fetchone()["n"]
    good=c.execute("SELECT COUNT(*) n FROM feedback WHERE action='good'").fetchone()["n"]
    bad=c.execute("SELECT COUNT(*) n FROM feedback WHERE action='bad'").fetchone()["n"]
    avg=c.execute("SELECT COALESCE(ROUND(AVG(score),1),0) n FROM vacancies").fetchone()["n"]
    c.close()
    await m.answer(f"<b>Статистика</b>\nВакансий: {total}\n👍: {good}\n👎: {bad}\nСредний score: {avg}")

@router.callback_query(F.data.startswith(("good:","bad:","hide:")))
async def feedback(q:CallbackQuery):
    if not owner_ok(q.from_user.id): return await q.answer("Нет доступа",show_alert=True)
    action, sid=q.data.split(":"); vid=int(sid); c=db()
    c.execute("""INSERT INTO feedback(vacancy_id,user_id,action,created_at) VALUES(?,?,?,?)
                 ON CONFLICT(vacancy_id,user_id) DO UPDATE SET action=excluded.action,created_at=excluded.created_at""",
              (vid,q.from_user.id,action,datetime.now(timezone.utc).isoformat()))
    c.commit(); c.close()
    await q.answer({"good":"Сохранено 👍","bad":"Сохранено 👎","hide":"Спрячу похожие в дальнейшем"}[action])

@router.channel_post()
async def channel_post(m:Message,bot:Bot):
    v=build_vacancy(m)
    if not v: return
    vid=store(v)
    if not vid: return
    v["id"]=vid
    c=db(); users=c.execute("SELECT user_id,chat_id FROM users").fetchall(); c.close()
    for u in users:
        s,ms=user_settings(u["user_id"])
        if v["score"]<s or (ms and v["salary"] and v["salary"]<ms): continue
        try: await bot.send_message(u["chat_id"],format_vacancy(v),reply_markup=vacancy_keyboard(v))
        except Exception as e: print("notify error:",e)

@router.edited_channel_post()
async def edited_channel_post(m:Message,bot:Bot):
    await channel_post(m,bot)

async def main():
    if not BOT_TOKEN or BOT_TOKEN=="PASTE_BOT_TOKEN_HERE":
        raise SystemExit("Заполни BOT_TOKEN в .env")
    init_db()
    bot=Bot(BOT_TOKEN,default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp=Dispatcher(); dp.include_router(router)
    await bot.delete_webhook(drop_pending_updates=False)
    print("Internship Radar Bot API started.")
    await dp.start_polling(bot,allowed_updates=["message","callback_query","channel_post","edited_channel_post"])

if __name__=="__main__":
    asyncio.run(main())
